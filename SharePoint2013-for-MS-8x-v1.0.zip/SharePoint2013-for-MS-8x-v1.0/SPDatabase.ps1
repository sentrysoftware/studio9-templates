﻿cd "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\15\CONFIG\POWERSHELL\Registration"
.\sharepoint.ps1
Get-SPDatabase| Select ID,Name,Type|ft -HideTableHeaders


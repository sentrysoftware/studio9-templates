Add-PSSnapin Microsoft.SharePoint.PowerShell
Get-SPEnterpriseSearchStatus -SearchApplication "Search Service Application"
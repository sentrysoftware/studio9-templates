﻿Add-PSSnapin Microsoft.SharePoint.PowerShell

Get-SPServiceApplicationPool | select Id, Name| ft -HideTableHeaders


﻿Add-PSSnapin Microsoft.SharePoint.PowerShell
Get-SPServiceInstance | Select Status,Service | ft -HideTableHeaders


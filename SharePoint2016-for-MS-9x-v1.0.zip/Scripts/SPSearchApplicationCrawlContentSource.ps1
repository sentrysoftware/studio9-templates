Add-PSSnapin Microsoft.SharePoint.PowerShell
Get-SPEnterpriseSearchCrawlContentSource -SearchApplication "Search Service Application"
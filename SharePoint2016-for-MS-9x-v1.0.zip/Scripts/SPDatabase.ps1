﻿Add-PSSnapin -Name Microsoft.SharePoint.PowerShell
Get-SPDatabase | Select ID,Name,Type|ft -HideTableHeaders